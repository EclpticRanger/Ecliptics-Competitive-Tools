from ecliptics_compedative_tools import E

print(E())