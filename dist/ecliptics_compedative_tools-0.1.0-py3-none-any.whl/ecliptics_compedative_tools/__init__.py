__version__ = "1.0.0"

# Re-export public symbols for convenience
from .main import E

__all__ = ["E", "__version__"]
